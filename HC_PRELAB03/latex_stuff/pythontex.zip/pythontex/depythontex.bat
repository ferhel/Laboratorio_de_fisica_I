@echo off
depythontex.py %*
