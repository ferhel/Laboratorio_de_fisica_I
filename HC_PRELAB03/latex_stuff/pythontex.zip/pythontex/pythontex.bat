@echo off
pythontex.py %*
